"""Inputs that a client such as Ari Helper fills in, and that also work in the editor.

Each takes the placeholder as text. While it is unfilled (running from the
editor, or the client sent nothing) the node uses its test value instead.
"""
import os
import re

import numpy as np
import torch
from PIL import Image, ImageOps

import folder_paths

# {{name}}, with or without the backslashes ComfyUI's prompt boxes need
PLACEHOLDER = re.compile(r"\s*\\?\{\\?\{\s*\w+\s*\\?\}\\?\}\s*")
NO_IMAGE = "none"


def filled(value):
    """What the client sent, or None if it sent nothing."""
    return None if not value.strip() or PLACEHOLDER.fullmatch(value) else value


class AriText:
    CATEGORY = "Ari Helper"
    RETURN_TYPES = ("STRING",)
    FUNCTION = "run"

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "from_ari": ("STRING", {"default": "{{prompt}}"}),
            "test_value": ("STRING", {"multiline": True, "default": ""}),
        }}

    def run(self, from_ari, test_value):
        value = filled(from_ari)
        return (test_value if value is None else value,)


class AriNumber:
    CATEGORY = "Ari Helper"
    RETURN_TYPES = ("INT",)
    FUNCTION = "run"

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "from_ari": ("STRING", {"default": "{{seed}}"}),
            "test_value": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff,
                                   "control_after_generate": True}),
        }}

    def run(self, from_ari, test_value):
        value = filled(from_ari)
        return (test_value if value is None else int(float(value)),)


def input_path(name):
    """Path of an image inside ComfyUI's input folder. The name comes from the network."""
    root = os.path.abspath(folder_paths.get_input_directory())
    path = os.path.abspath(folder_paths.get_annotated_filepath(name, root))
    if os.path.commonpath((root, path)) != root:
        raise ValueError(f"Start image must be in ComfyUI's input folder: {name}")
    return path


def chosen_image(from_ari, test_image):
    value = filled(from_ari)
    if value is not None:
        return value
    return None if test_image == NO_IMAGE else test_image


class AriStartImage:
    """Ari's picture, else the test picture, else the generated one (only then is it made)."""
    CATEGORY = "Ari Helper"
    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "run"

    @classmethod
    def INPUT_TYPES(cls):
        root = folder_paths.get_input_directory()
        files = [f for f in os.listdir(root) if os.path.isfile(os.path.join(root, f))]
        images = sorted(folder_paths.filter_files_content_types(files, ["image"]))
        return {
            "required": {
                "from_ari": ("STRING", {"default": "{{image}}"}),
                "test_image": ([NO_IMAGE] + images, {"image_upload": True}),
            },
            "optional": {"generated": ("IMAGE", {"lazy": True})},
        }

    @classmethod
    def VALIDATE_INPUTS(cls, test_image):
        # a saved test picture that is missing on this PC must not block Ari's runs
        return True

    @classmethod
    def IS_CHANGED(cls, from_ari, test_image, generated=None):
        # file names get reused, so compare the file itself
        name = chosen_image(from_ari, test_image)
        if name is None:
            return ""
        info = os.stat(input_path(name))
        return f"{info.st_mtime_ns}:{info.st_size}"

    def check_lazy_status(self, from_ari, test_image, generated=None):
        return ["generated"] if chosen_image(from_ari, test_image) is None and generated is None else []

    def run(self, from_ari, test_image, generated=None):
        name = chosen_image(from_ari, test_image)
        if name is None:
            if generated is None:
                raise ValueError("No start image: pick a test_image or connect 'generated'.")
            return (generated,)
        with Image.open(input_path(name)) as image:
            pixels = np.array(ImageOps.exif_transpose(image).convert("RGB"), dtype=np.float32) / 255.0
        return (torch.from_numpy(pixels)[None,],)


NODE_CLASS_MAPPINGS = {"AriText": AriText, "AriNumber": AriNumber, "AriStartImage": AriStartImage}
NODE_DISPLAY_NAME_MAPPINGS = {"AriText": "Ari Text", "AriNumber": "Ari Number", "AriStartImage": "Ari Start Image"}
