"""Delete ARI Helper videos from the PC once they have been downloaded.

Only jobs that save under output/ari-private/ AND were not queued from the
ComfyUI editor are touched, so your own test runs are kept. For those jobs:
  * the video is deleted shortly after a client downloads all of it from /view
  * the start image the client uploaded is deleted along with it
  * the job, including its prompts, is removed from ComfyUI's history
  * anything never downloaded is deleted after EXPIRE_MINUTES

This is ordinary file deletion, not secure erasure.
"""
import json
import logging
import os
import threading
import time

from aiohttp import web

import folder_paths
from server import PromptServer

from .nodes import chosen_image, input_path

FOLDER = "ari-private"
GRACE_SECONDS = float(os.environ.get("ARI_CLEANUP_GRACE_SECONDS", 60))
EXPIRE_MINUTES = float(os.environ.get("ARI_CLEANUP_EXPIRE_MINUTES", 60))

server = PromptServer.instance
output_dir = os.path.join(folder_paths.get_output_directory(), FOLDER)
state_file = os.path.join(folder_paths.get_user_directory(), "ari_private_cleanup.json")

lock = threading.Lock()
uploads = set()    # input files created by /upload/image since startup
delivered = {}     # video path -> time it may be deleted
finished = {}      # history id of a private job -> time first seen finished
try:
    with open(state_file, encoding="utf-8") as f:
        state = json.load(f)
except (OSError, ValueError):
    state = {}
inputs = state.get("inputs", {})  # start image path -> time its job was queued, or 0 when released
videos = state.get("videos", {})  # video path made by a client job -> time first seen


def save_state():
    with open(state_file, "w", encoding="utf-8") as f:
        json.dump({"inputs": inputs, "videos": videos}, f)


def is_private(graph, extra_data):
    # the editor sends its workflow along with each job; API clients don't
    if "extra_pnginfo" in (extra_data or {}):
        return False
    return any(
        str(node.get("inputs", {}).get("filename_prefix", "")).startswith(FOLDER + "/")
        for node in graph.values() if isinstance(node, dict)
    )


def input_images(graph):
    for node in graph.values():
        if not isinstance(node, dict):
            continue
        values = node.get("inputs", {})
        name = None
        if node.get("class_type") == "LoadImage":
            name = values.get("image")
        elif node.get("class_type") == "AriStartImage":
            # only the client's picture, never the editor's test picture
            name = chosen_image(str(values.get("from_ari", "")), "none")
        if isinstance(name, str):
            try:
                yield input_path(name)
            except ValueError:
                pass


def remove(path):
    """True once the file is gone. Windows refuses while it is still being read."""
    try:
        os.remove(path)
        logging.info("[ari-cleanup] deleted %s", os.path.basename(path))
    except FileNotFoundError:
        pass
    except OSError:
        return False
    return True


def on_prompt(json_data):
    graph = json_data.get("prompt")
    try:
        if isinstance(graph, dict) and is_private(graph, json_data.get("extra_data")):
            with lock:
                for path in input_images(graph):
                    if path in uploads:
                        inputs[path] = time.time()
                save_state()
    except Exception:
        logging.exception("[ari-cleanup] could not track a start image")
    return json_data


def output_videos(entry):
    for node in entry.get("outputs", {}).values():
        for items in node.values():
            for item in items if isinstance(items, (list, tuple)) else []:
                if isinstance(item, dict) and item.get("subfolder") == FOLDER:
                    yield os.path.join(output_dir, item["filename"])


def sweep():
    now = time.time()
    expired = now - EXPIRE_MINUTES * 60
    queue = server.prompt_queue
    running, pending = queue.get_current_queue_volatile()
    in_use = {path for item in running + pending for path in input_images(item[2])}
    history = {k: v for k, v in queue.get_history().items() if is_private(v["prompt"][2], v["prompt"][3])}

    with lock:
        for entry in history.values():
            for path in output_videos(entry):
                videos.setdefault(path, now)

        gone = set()
        for path, due in list(delivered.items()):
            if now < due:
                continue
            if path not in videos:
                del delivered[path]
            elif remove(path):
                del delivered[path]
                gone.add(path)

        for job_id, entry in history.items():
            first_seen = finished.setdefault(job_id, now)
            if set(output_videos(entry)) & gone or first_seen < expired:
                for path in input_images(entry["prompt"][2]):
                    if path in inputs:
                        inputs[path] = 0
                queue.delete_history_item(job_id)
                finished.pop(job_id, None)

        for path, queued_at in list(inputs.items()):
            if path not in in_use and queued_at < expired and remove(path):
                del inputs[path]
                uploads.discard(path)

        for path, first_seen in list(videos.items()):
            if path in gone or not os.path.exists(path) or (first_seen < expired and remove(path)):
                del videos[path]
        save_state()


def run_sweeps():
    while True:
        time.sleep(max(1, min(10, GRACE_SECONDS)))
        try:
            sweep()
        except Exception:
            logging.exception("[ari-cleanup] sweep failed")


def whole_file_sent(response):
    if response.status == 200:
        return True
    # a ranged request counts only if it covered the file from start to end
    content_range = response.headers.get("Content-Range", "")
    if response.status == 206 and content_range.startswith("bytes 0-"):
        end, total = content_range[len("bytes 0-"):].split("/")
        return int(end) + 1 == int(total)
    return False


@web.middleware
async def watch_downloads(request, handler):
    route = request.path.removeprefix("/api")

    if route == "/upload/image" and request.method == "POST":
        started = time.time()
        response = await handler(request)
        if response.status == 200:
            info = json.loads(response.body)
            if info.get("type") == "input":
                path = os.path.abspath(os.path.join(
                    folder_paths.get_input_directory(), info.get("subfolder", ""), info["name"]))
                # an upload that matched a file already on disk is not ours to delete
                if os.path.getmtime(path) >= started - 2:
                    uploads.add(path)
        return response

    response = await handler(request)
    query = request.query
    if (route == "/view" and request.method == "GET" and isinstance(response, web.FileResponse)
            and query.get("subfolder") == FOLDER and query.get("type", "output") == "output"):
        path = os.path.join(output_dir, os.path.basename(query.get("filename", "")))
        notify_when_sent(response, path)
    return response


def notify_when_sent(response, path):
    send = response.prepare

    # FileResponse sends the whole body inside prepare(); a dropped connection raises
    async def prepare(request):
        writer = await send(request)
        if whole_file_sent(response) and request.transport is not None:
            with lock:
                delivered.setdefault(path, time.time() + GRACE_SECONDS)
        return writer

    response.prepare = prepare


server.app.middlewares.append(watch_downloads)
server.add_on_prompt_handler(on_prompt)
threading.Thread(target=run_sweeps, daemon=True, name="ari-private-cleanup").start()
logging.info("[ari-cleanup] on: %s/ deleted %ss after download, or after %s min",
             FOLDER, int(GRACE_SECONDS), int(EXPIRE_MINUTES))
