# SDXL + Wan 2.2 video workflow for Ari Helper

One workflow for both kinds of request:

- **Text only:** SDXL makes a still from your prompt, then Wan 2.2 animates it.
- **With a picture:** Wan 2.2 animates your picture. SDXL is skipped.

| File | What it's for |
|---|---|
| `sdxl-video-gen-ari.json` | Open and edit in ComfyUI |
| `sdxl-video-gen-ari-api.json` | Import into Ari Helper |
| `ari_helper_nodes/` | **Required** ComfyUI add-on: the Ari input nodes and cleanup |

The output is H.264 MP4. Apart from the add-on, the workflow uses built-in ComfyUI nodes. It needs no extra Python packages and was built on ComfyUI 0.46.0.

## Setup

1. Copy the `ari_helper_nodes` folder into `ComfyUI/custom_nodes/` and restart ComfyUI. The startup log shows `[ari-cleanup] on`.
2. Put these models in the matching folders under `ComfyUI/models/`:

| Folder | File |
|---|---|
| `checkpoints` | `sd_xl_base_1.0.safetensors` |
| `diffusion_models` | `wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors` |
| `diffusion_models` | `wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors` |
| `loras` | `wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors` |
| `loras` | `wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors` |
| `text_encoders` | `umt5_xxl_fp8_e4m3fn_scaled.safetensors` |
| `vae` | `wan_2.1_vae.safetensors` |

3. In Ari, open **Settings > Self-Hosted > ComfyUI > Import workflow file** and choose `sdxl-video-gen-ari-api.json`.

## Editing in ComfyUI

Open `sdxl-video-gen-ari.json`. The inputs are grouped under **Ari Helper inputs**. Each has two parts:

- `from_ari` holds the placeholder, such as `{{seed}}`. **Leave it as it is.** Type it without backslashes.
- `test_value` (or `test_image`) is used while the placeholder is unfilled, so **Run** works in the editor. Change it freely.

If Ari doesn't send a value, the test value is used. This means your test values are also your defaults. The seed's test value changes after each editor run. If Ari sends no seed, it gets whichever value was exported.

To use your changes in Ari, choose **Workflow > Export (API)** and import the new file.

| To change | Node | Setting |
|---|---|---|
| Largest video size | `SETTING: max video pixels` | `921600` is about 720p. Use `399360` (832x480) for speed or less memory |
| Clip length | `Image to video (81 frames)` | `length`: 81 frames is about 5 seconds at 16 fps |

## Writing prompts

Use `|||` to give the still picture and the video separate prompts:

```
a red fox in a snowy forest, wildlife photograph ||| the fox slowly turns its head as snow falls
```

- Left of `|||` describes the picture. Right of it describes the motion.
- Without `|||`, both get the whole prompt.
- If one side is empty, both get the other side.
- Only the first `|||` splits the prompt.
- When you attach a picture, only the motion side is used.

## What Ari fills in

| Placeholder | Used for |
|---|---|
| `{{prompt}}` | Picture and motion prompts, split as above |
| `{{negative_prompt}}` | Things to avoid (see the note below) |
| `{{seed}}` | All sampling passes |
| `{{width}}`, `{{height}}` | Video size |
| `{{image}}` | Start picture |

**Size:** the video keeps the shape you ask for. Sizes are rounded to multiples of 16, and anything over the pixel limit is scaled down (1920x1080 becomes 1280x720). The SDXL still is made at about 1 megapixel in the same shape. Your own picture is center-cropped to fit.

**Negative prompt:** the video passes run at CFG 1 for speed, which ignores negative prompts. It affects only the SDXL still, so it does nothing when you attach a picture.

## Cleanup after download

It only acts on jobs that save into `output/ari-private/` and come from a client such as Ari. **Runs started from the ComfyUI editor are kept.**

- About 60 seconds after the whole video has been downloaded, it deletes the video, the start picture the client uploaded, and the job's history entry, which contains your prompts.
- Anything never downloaded is deleted after about 60 minutes.
- An interrupted download keeps the video so it can be retried.
- Files that were already in your `input` folder before an upload are left alone.
- Other tools that call ComfyUI's API with this workflow are treated like Ari.

To change the timing, set `ARI_CLEANUP_GRACE_SECONDS` or `ARI_CLEANUP_EXPIRE_MINUTES` in the environment ComfyUI starts from. To keep client videos, change the save node's `filename_prefix` so it doesn't start with `ari-private/`.

### What it doesn't protect

- Deletion is ordinary file deletion. It isn't secure erase, and it doesn't reach backups or cloud-synced copies.
- For a client's job, any complete download counts, including viewing it from another device or browser.
- By default, ComfyUI embeds the workflow, **including your prompts**, inside each MP4, so the downloaded copy has it too. To stop this, start ComfyUI with `--disable-metadata`. That applies to all your workflows.
- Until cleanup runs, anyone who can reach your ComfyUI port can see the files and prompts. Keep it on your home network or Tailscale.
- Start pictures uploaded for jobs that ComfyUI rejects are not removed.
- If ComfyUI restarts between an upload and its job being queued, that picture is not removed.
